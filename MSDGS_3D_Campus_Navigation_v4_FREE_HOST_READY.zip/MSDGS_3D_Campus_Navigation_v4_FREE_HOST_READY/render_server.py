import os
from waitress import serve
from app import app, init_db

if __name__ == "__main__":
    # Render free instances have ephemeral local storage.
    # /tmp is used only for demo/testing unless an external persistent DB is added later.
    os.environ.setdefault("MSDGS_DB_PATH", "/tmp/msdgs_navigation.db")
    init_db()
    serve(app, host="0.0.0.0", port=int(os.environ.get("PORT", "10000")), threads=8)
