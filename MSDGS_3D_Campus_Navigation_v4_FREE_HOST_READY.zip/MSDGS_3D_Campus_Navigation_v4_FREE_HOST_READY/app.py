
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, uuid, heapq, math, json
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.environ.get("MSDGS_DB_PATH") or os.path.join(BASE, "data", "msdgs_navigation.db")
app = Flask(__name__)
app.secret_key = os.environ.get("MSDGS_SECRET") or os.urandom(32)

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'SUPER_ADMIN'
);
CREATE TABLE IF NOT EXISTS branches(
 id TEXT PRIMARY KEY, name TEXT NOT NULL, code TEXT UNIQUE NOT NULL,
 address TEXT, city TEXT, state TEXT, description TEXT, image TEXT,
 status TEXT NOT NULL DEFAULT 'DRAFT', published_version INTEGER DEFAULT 0,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS buildings(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, name TEXT NOT NULL,
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS floors(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, building_id TEXT NOT NULL,
 name TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 0,
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE,
 FOREIGN KEY(building_id) REFERENCES buildings(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS locations(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, building_id TEXT,
 floor_id TEXT, name TEXT NOT NULL, kind TEXT DEFAULT 'ROOM',
 x REAL DEFAULT 0, y REAL DEFAULT 0, z REAL DEFAULT 0,
 is_public INTEGER DEFAULT 1,
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE,
 FOREIGN KEY(building_id) REFERENCES buildings(id) ON DELETE SET NULL,
 FOREIGN KEY(floor_id) REFERENCES floors(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS navigation_edges(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, from_node TEXT NOT NULL,
 to_node TEXT NOT NULL, distance REAL NOT NULL DEFAULT 1, bidirectional INTEGER DEFAULT 1,
 instruction TEXT DEFAULT '',
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE,
 FOREIGN KEY(from_node) REFERENCES locations(id) ON DELETE CASCADE,
 FOREIGN KEY(to_node) REFERENCES locations(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS map_versions(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, version INTEGER NOT NULL,
 status TEXT NOT NULL, snapshot TEXT NOT NULL, created_at TEXT NOT NULL,
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS mapping_sessions(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, building_id TEXT, floor_id TEXT,
 start_id TEXT, destination_id TEXT, status TEXT DEFAULT 'DRAFT',
 checkpoints TEXT DEFAULT '[]', created_at TEXT NOT NULL,
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS qr_anchors(
 id TEXT PRIMARY KEY, branch_id TEXT NOT NULL, location_id TEXT NOT NULL,
 code TEXT UNIQUE NOT NULL,
 FOREIGN KEY(branch_id) REFERENCES branches(id) ON DELETE CASCADE,
 FOREIGN KEY(location_id) REFERENCES locations(id) ON DELETE CASCADE
);
"""

def conn():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def uid(prefix):
    return prefix + uuid.uuid4().hex[:10].upper()

def now():
    return datetime.utcnow().isoformat(timespec="seconds")

def init_db():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    c=conn(); c.executescript(SCHEMA)
    if not c.execute("select 1 from users limit 1").fetchone():
        c.execute("insert into users(username,password_hash,role) values(?,?,?)",
                  ("admin", generate_password_hash("ChangeMe123!"), "SUPER_ADMIN"))
    c.commit(); c.close()

def admin_required(fn):
    from functools import wraps
    @wraps(fn)
    def wrap(*a, **kw):
        if not session.get("admin"):
            return redirect(url_for("admin_login"))
        return fn(*a, **kw)
    return wrap

def rowdicts(rows): return [dict(r) for r in rows]

@app.route("/")
def home():
    return render_template("public.html")

@app.route("/api/public/branches")
def public_branches():
    c=conn()
    rows=c.execute("""select id,name,code,city,state,published_version from branches
                      where status='ACTIVE' and published_version>0 order by name""").fetchall()
    c.close(); return jsonify(rowdicts(rows))

@app.route("/api/public/branches/<bid>/locations")
def public_locations(bid):
    c=conn()
    b=c.execute("select * from branches where id=? and status='ACTIVE' and published_version>0",(bid,)).fetchone()
    if not b: c.close(); return jsonify([]),404
    rows=c.execute("""select l.id,l.name,l.kind,l.x,l.y,l.z,
      coalesce(b.name,'') building,coalesce(f.name,'') floor,coalesce(f.level,0) floor_level
      from locations l left join buildings b on b.id=l.building_id
      left join floors f on f.id=l.floor_id
      where l.branch_id=? and l.is_public=1 order by l.name""",(bid,)).fetchall()
    c.close(); return jsonify(rowdicts(rows))

def shortest_route(c,bid,start,end):
    locs={r["id"]:dict(r) for r in c.execute("""select l.*,coalesce(f.level,0) floor_level,
        coalesce(f.name,'') floor_name,coalesce(b.name,'') building_name
        from locations l left join floors f on f.id=l.floor_id
        left join buildings b on b.id=l.building_id where l.branch_id=?""",(bid,))}
    if start not in locs or end not in locs: return None
    adj={k:[] for k in locs}
    for e in c.execute("select * from navigation_edges where branch_id=?",(bid,)):
        if e["from_node"] in adj and e["to_node"] in adj:
            adj[e["from_node"]].append((e["to_node"],float(e["distance"]),e["instruction"]))
            if e["bidirectional"]:
                adj[e["to_node"]].append((e["from_node"],float(e["distance"]),e["instruction"]))
    pq=[(0,start)]; dist={start:0}; prev={}; instr={}
    while pq:
        d,u=heapq.heappop(pq)
        if u==end: break
        if d!=dist.get(u): continue
        for v,w,ins in adj.get(u,[]):
            nd=d+w
            if nd < dist.get(v,float("inf")):
                dist[v]=nd; prev[v]=u; instr[v]=ins; heapq.heappush(pq,(nd,v))
    if end not in dist: return None
    ids=[]; u=end
    while True:
        ids.append(u)
        if u==start: break
        u=prev[u]
    ids.reverse()
    steps=[]
    for i,nid in enumerate(ids):
        x=dict(locs[nid]); x["instruction"]= instr.get(nid,"Start" if i==0 else "")
        steps.append(x)
    return {"distance":round(dist[end],1),"steps":steps}

@app.route("/api/public/route")
def api_route():
    bid=request.args.get("branch"); start=request.args.get("from"); end=request.args.get("to")
    c=conn()
    b=c.execute("select * from branches where id=? and status='ACTIVE' and published_version>0",(bid,)).fetchone()
    if not b: c.close(); return jsonify({"error":"Branch is not published"}),404
    route=shortest_route(c,bid,start,end); c.close()
    if not route: return jsonify({"error":"No valid route found"}),404
    route["branch"]={"id":b["id"],"name":b["name"],"version":b["published_version"]}
    return jsonify(route)

@app.route("/navigate")
def navigate():
    return render_template("navigate.html", branch=request.args.get("branch",""),
                           start=request.args.get("from",""), dest=request.args.get("to",""))

@app.route("/q/<code>")
def qr(code):
    c=conn(); q=c.execute("select branch_id,location_id from qr_anchors where code=?",(code,)).fetchone(); c.close()
    if not q: return "QR anchor not found",404
    return redirect(url_for("home", branch=q["branch_id"], start=q["location_id"]))

@app.route("/admin/login",methods=["GET","POST"])
def admin_login():
    if request.method=="POST":
        c=conn(); u=c.execute("select * from users where username=?",(request.form["username"],)).fetchone(); c.close()
        if u and check_password_hash(u["password_hash"],request.form["password"]):
            session["admin"]=u["username"]; return redirect(url_for("admin"))
        flash("Invalid credentials")
    return render_template("login.html")

@app.route("/admin/logout")
def logout(): session.clear(); return redirect(url_for("home"))

@app.route("/admin")
@admin_required
def admin():
    c=conn()
    rows=c.execute("""select b.*,
      (select count(*) from buildings x where x.branch_id=b.id) buildings,
      (select count(*) from floors x where x.branch_id=b.id) floors,
      (select count(*) from locations x where x.branch_id=b.id) locations,
      (select count(*) from navigation_edges x where x.branch_id=b.id) routes
      from branches b order by b.created_at desc""").fetchall()
    c.close(); return render_template("admin.html",branches=rows)

@app.route("/admin/password",methods=["POST"])
@admin_required
def password():
    p=request.form.get("password","")
    if len(p)<8: flash("Password must be at least 8 characters"); return redirect(url_for("admin"))
    c=conn(); c.execute("update users set password_hash=? where username=?",(generate_password_hash(p),session["admin"])); c.commit(); c.close()
    flash("Password changed"); return redirect(url_for("admin"))

@app.route("/admin/branch/new",methods=["POST"])
@admin_required
def branch_new():
    f=request.form; bid=uid("BR")
    c=conn()
    try:
        c.execute("""insert into branches(id,name,code,address,city,state,description,image,status,created_at,updated_at)
          values(?,?,?,?,?,?,?,?,?,?,?)""",(bid,f["name"],f["code"],f.get("address",""),f.get("city",""),
          f.get("state",""),f.get("description",""),f.get("image",""),f.get("status","DRAFT"),now(),now()))
        c.commit(); flash("Branch created")
    except Exception as e: flash("Could not create branch: "+str(e))
    c.close(); return redirect(url_for("admin"))

@app.route("/admin/branch/<bid>")
@admin_required
def branch_manage(bid):
    c=conn(); b=c.execute("select * from branches where id=?",(bid,)).fetchone()
    if not b: c.close(); return "Branch not found",404
    buildings=c.execute("select * from buildings where branch_id=? order by name",(bid,)).fetchall()
    floors=c.execute("""select f.*,b.name building_name from floors f join buildings b on b.id=f.building_id
                       where f.branch_id=? order by b.name,f.level""",(bid,)).fetchall()
    locs=c.execute("""select l.*,coalesce(b.name,'') building_name,coalesce(f.name,'') floor_name
                      from locations l left join buildings b on b.id=l.building_id
                      left join floors f on f.id=l.floor_id where l.branch_id=? order by l.name""",(bid,)).fetchall()
    edges=c.execute("""select e.*,a.name from_name,z.name to_name from navigation_edges e
                       join locations a on a.id=e.from_node join locations z on z.id=e.to_node
                       where e.branch_id=?""",(bid,)).fetchall()
    versions=c.execute("select * from map_versions where branch_id=? order by version desc",(bid,)).fetchall()
    c.close()
    return render_template("branch.html",b=b,buildings=buildings,floors=floors,locs=locs,edges=edges,versions=versions)

@app.route("/admin/branch/<bid>/status",methods=["POST"])
@admin_required
def branch_status(bid):
    c=conn(); c.execute("update branches set status=?,updated_at=? where id=?",(request.form["status"],now(),bid)); c.commit(); c.close()
    return redirect(url_for("branch_manage",bid=bid))

@app.route("/admin/branch/<bid>/building",methods=["POST"])
@admin_required
def add_building(bid):
    c=conn(); c.execute("insert into buildings(id,branch_id,name) values(?,?,?)",(uid("BLD"),bid,request.form["name"])); c.commit(); c.close()
    return redirect(url_for("branch_manage",bid=bid))

@app.route("/admin/branch/<bid>/floor",methods=["POST"])
@admin_required
def add_floor(bid):
    c=conn(); c.execute("insert into floors(id,branch_id,building_id,name,level) values(?,?,?,?,?)",
                        (uid("FLR"),bid,request.form["building_id"],request.form["name"],int(request.form["level"]))); c.commit(); c.close()
    return redirect(url_for("branch_manage",bid=bid))

@app.route("/admin/branch/<bid>/location",methods=["POST"])
@admin_required
def add_location(bid):
    f=request.form; c=conn()
    floor=c.execute("select * from floors where id=? and branch_id=?",(f["floor_id"],bid)).fetchone()
    if not floor: c.close(); return "Invalid floor",400
    lid=uid("LOC")
    c.execute("""insert into locations(id,branch_id,building_id,floor_id,name,kind,x,y,z,is_public)
      values(?,?,?,?,?,?,?,?,?,?)""",(lid,bid,floor["building_id"],floor["id"],f["name"],f.get("kind","ROOM"),
      float(f.get("x",0)),float(f.get("y",0)),float(f.get("z",0)),1))
    c.commit(); c.close(); return redirect(url_for("branch_manage",bid=bid))

@app.route("/admin/branch/<bid>/edge",methods=["POST"])
@admin_required
def add_edge(bid):
    f=request.form; c=conn()
    a=c.execute("select id from locations where id=? and branch_id=?",(f["from_node"],bid)).fetchone()
    z=c.execute("select id from locations where id=? and branch_id=?",(f["to_node"],bid)).fetchone()
    if not a or not z: c.close(); return "Cross-branch/invalid route blocked",400
    c.execute("""insert into navigation_edges(id,branch_id,from_node,to_node,distance,bidirectional,instruction)
                 values(?,?,?,?,?,?,?)""",(uid("EDG"),bid,f["from_node"],f["to_node"],float(f["distance"]),
                 1 if f.get("bidirectional") else 0,f.get("instruction","")))
    c.commit(); c.close(); return redirect(url_for("branch_manage",bid=bid))

@app.route("/admin/branch/<bid>/publish",methods=["POST"])
@admin_required
def publish(bid):
    c=conn()
    b=c.execute("select * from branches where id=?",(bid,)).fetchone()
    if not b: c.close(); return "Not found",404
    locs=rowdicts(c.execute("select * from locations where branch_id=?",(bid,)).fetchall())
    edges=rowdicts(c.execute("select * from navigation_edges where branch_id=?",(bid,)).fetchall())
    if len(locs)<2 or len(edges)<1:
        flash("Need at least 2 locations and 1 route before publishing"); c.close(); return redirect(url_for("branch_manage",bid=bid))
    v=int(b["published_version"])+1
    snap=json.dumps({"locations":locs,"edges":edges})
    c.execute("insert into map_versions(id,branch_id,version,status,snapshot,created_at) values(?,?,?,?,?,?)",
              (uid("VER"),bid,v,"PUBLISHED",snap,now()))
    c.execute("update branches set published_version=?,status='ACTIVE',updated_at=? where id=?",(v,now(),bid))
    c.commit(); c.close(); flash(f"Published version {v}")
    return redirect(url_for("branch_manage",bid=bid))

@app.route("/admin/branch/<bid>/mapping")
@admin_required
def mapping(bid):
    c=conn(); b=c.execute("select * from branches where id=?",(bid,)).fetchone()
    locs=c.execute("select * from locations where branch_id=? order by name",(bid,)).fetchall(); c.close()
    return render_template("mapping.html",b=b,locs=locs)

@app.route("/api/admin/mapping",methods=["POST"])
@admin_required
def save_mapping():
    d=request.json or {}; bid=d.get("branch_id")
    c=conn()
    for k in ("start_id","destination_id"):
        if not c.execute("select 1 from locations where id=? and branch_id=?",(d.get(k),bid)).fetchone():
            c.close(); return jsonify({"error":"Invalid branch location"}),400
    mid=uid("MAP")
    c.execute("""insert into mapping_sessions(id,branch_id,start_id,destination_id,status,checkpoints,created_at)
                 values(?,?,?,?,?,?,?)""",(mid,bid,d["start_id"],d["destination_id"],"REVIEW",
                 json.dumps(d.get("checkpoints",[])),now()))
    c.commit(); c.close(); return jsonify({"ok":True,"id":mid})

@app.route("/admin/demo",methods=["POST"])
@admin_required
def demo():
    c=conn()
    if c.execute("select 1 from branches where code='DEMO'").fetchone():
        c.close(); flash("Demo already exists"); return redirect(url_for("admin"))
    bid=uid("BR"); t=now()
    c.execute("insert into branches(id,name,code,address,city,state,description,status,created_at,updated_at) values(?,?,?,?,?,?,?,?,?,?)",
              (bid,"MSDGS Demo Campus","DEMO","Demo Address","Demo City","Demo State","Demo navigation campus","DRAFT",t,t))
    bld=uid("BLD"); c.execute("insert into buildings values(?,?,?)",(bld,bid,"Main Building"))
    floors=[]
    for name,level in [("Ground Floor",0),("First Floor",1),("Second Floor",2)]:
        fid=uid("FLR"); floors.append(fid); c.execute("insert into floors values(?,?,?,?,?)",(fid,bid,bld,name,level))
    pts=[("Front Gate",0,0,0,0),("Reception",0,4,0,0),("Staircase A",0,8,0,0),
         ("Staircase A - First",1,8,4,3),("First Floor Lobby",1,5,4,3),
         ("Staircase A - Second",2,8,8,6),("Computer Lab",2,4,8,6)]
    lids=[]
    for name,fi,x,y,z in pts:
        lid=uid("LOC"); lids.append(lid)
        c.execute("insert into locations values(?,?,?,?,?,?,?,?,?,?)",(lid,bid,bld,floors[fi],name,"NAV",x,y,z,1))
    for i in range(len(lids)-1):
        a=pts[i]; z=pts[i+1]
        d=round(math.sqrt((a[2]-z[2])**2+(a[3]-z[3])**2+(a[4]-z[4])**2),1)
        ins="Continue"
        if a[1]!=z[1]: ins=f"Go to {['Ground Floor','First Floor','Second Floor'][z[1]]}"
        c.execute("insert into navigation_edges values(?,?,?,?,?,?,?)",(uid("EDG"),bid,lids[i],lids[i+1],max(d,1),1,ins))
    c.commit(); c.close()
    with app.test_request_context():
        pass
    # publish via same logic inline
    c=conn(); locs=rowdicts(c.execute("select * from locations where branch_id=?",(bid,)).fetchall())
    edges=rowdicts(c.execute("select * from navigation_edges where branch_id=?",(bid,)).fetchall())
    c.execute("insert into map_versions values(?,?,?,?,?,?)",(uid("VER"),bid,1,"PUBLISHED",json.dumps({"locations":locs,"edges":edges}),now()))
    c.execute("update branches set published_version=1,status='ACTIVE' where id=?",(bid,)); c.commit(); c.close()
    flash("Demo campus created and published"); return redirect(url_for("admin"))

if __name__=="__main__":
    init_db()
    app.run(host="0.0.0.0",port=8080,debug=False)
