# MSDGS 3D Campus Navigation v1

A working MVP package for dynamic, unlimited multi-branch indoor campus navigation.

## Included
- Unlimited database-driven branches
- Super Admin dashboard
- Add/edit branches, buildings, floors, locations
- Branch-isolated navigation nodes/routes
- Draft -> Publish map workflow
- Public no-login navigation
- Searchable branch/start/destination selectors
- Shortest-route calculation (Dijkstra)
- Floor-aware animated 3D-style route viewer
- Optional QR/deep-link route URLs
- Admin-only camera mapping page
- SQLite database
- Mobile-first UI
- Demo branch/data seeder

## Requirements
- Windows 10/11 or Windows Server
- Python 3.11+
- Internet is only needed initially to install Flask. The application itself does not use paid APIs.

## Start
1. Run `INSTALL.bat` once.
2. Run `START.bat`.
3. Open: http://127.0.0.1:8080

Admin:
- URL: http://127.0.0.1:8080/admin/login
- Username: admin
- Password: ChangeMe123!

Change the admin password immediately from the Admin page.

## Network access
Run on the server and open:
`http://SERVER-IP:8080`

For production/public internet use, place this behind HTTPS/reverse proxy and do not expose Flask directly.

## Important mapping note
This package implements the full branch/data/navigation architecture and a practical route editor. Browser camera mapping can record an admin mapping session and route checkpoints, but a phone camera alone cannot derive survey-grade indoor coordinates. Admin-approved coordinates/checkpoints are therefore saved to the navigation graph and published to users.

## Folder
- `app.py` - application/backend
- `templates/` - UI
- `static/` - CSS/JS
- `data/msdgs_navigation.db` - created automatically


## V2 Offline / No-Internet Floor Support
This version is PWA/offline capable.

Recommended visitor workflow:
1. At the gate/reception while connected to school Wi-Fi/mobile internet, open the navigation site.
2. Select the required branch.
3. Tap **DOWNLOAD THIS BRANCH FOR OFFLINE USE**.
4. Select Start Point and Destination and start navigation.
5. If Wi-Fi/mobile internet disappears on upper floors, cached navigation pages, locations and routes continue to work.
6. When connectivity returns, the application automatically uses the network again and refreshes cached responses.

### Important
- Initial loading/downloading must happen while the device has connectivity.
- Offline mode does not provide live indoor position tracking. It displays the pre-published route, landmarks, turns and floor changes.
- Admin camera mapping still requires browser camera permission and should normally be done while connected.
- For a production deployment, HTTPS is strongly recommended. Service workers and camera APIs have browser security requirements; localhost is allowed for development.

## V3 Internet-Hosting Ready
This package adds a Waitress production application server, environment-based secrets/ports, an HTTPS reverse-proxy example, and a public deployment guide under `deployment/`.

For local testing continue using `START.bat`.
For production use `START_PRODUCTION.bat` behind HTTPS/reverse proxy.

## V4 Free Hosting Ready
For free internet testing, use the included Render configuration. See:
`deployment/FREE_HOSTING_GUIDE.md`

A Netlify static preview is included, but the complete Flask Admin/API application requires server-side execution.
