
(function(){
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>navigator.serviceWorker.register('/static/sw.js'));
  }
  function banner(){
    let b=document.getElementById('offlineBanner');
    if(!b){b=document.createElement('div');b.id='offlineBanner';b.className='offline-banner';document.body.appendChild(b);}
    if(navigator.onLine){b.textContent='Online';b.classList.remove('show');}
    else {b.textContent='OFFLINE MODE — downloaded campus navigation remains available';b.classList.add('show');}
  }
  addEventListener('online',banner); addEventListener('offline',banner); addEventListener('DOMContentLoaded',banner);

  window.cacheBranchForOffline=async function(branchId){
    if(!('caches' in window)) return false;
    const c=await caches.open('msdgs-nav-v2');
    const locUrl='/api/public/branches/'+branchId+'/locations';
    try{
      const locResp=await fetch(locUrl); await c.put(locUrl,locResp.clone());
      const locs=await locResp.json();
      // Pre-cache all valid route responses for this branch so a destination can be selected offline.
      // Suitable for campus-sized datasets; future large deployments can switch to graph snapshot caching.
      const jobs=[];
      for(const a of locs) for(const b of locs){
        if(a.id!==b.id){
          const u=`/api/public/route?branch=${branchId}&from=${a.id}&to=${b.id}`;
          jobs.push(fetch(u).then(r=>{if(r.ok)return c.put(u,r.clone())}).catch(()=>null));
        }
      }
      // throttle in batches
      for(let i=0;i<jobs.length;i+=20) await Promise.all(jobs.slice(i,i+20));
      localStorage.setItem('offlineBranch:'+branchId, new Date().toISOString());
      return true;
    }catch(e){return false;}
  };
})();
