import os
from waitress import serve
from app import app, init_db

if __name__ == "__main__":
    init_db()
    host = os.environ.get("MSDGS_HOST", "127.0.0.1")
    port = int(os.environ.get("MSDGS_PORT", "8080"))
    threads = int(os.environ.get("MSDGS_THREADS", "12"))
    serve(app, host=host, port=port, threads=threads)
