@echo off
cd /d "%~dp0"
py -3.11 -m venv .venv 2>nul
if errorlevel 1 python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Installation complete.
pause
