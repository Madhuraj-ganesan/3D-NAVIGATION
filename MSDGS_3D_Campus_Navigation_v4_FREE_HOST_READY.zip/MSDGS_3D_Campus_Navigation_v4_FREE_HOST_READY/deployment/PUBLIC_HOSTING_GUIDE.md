# MSDGS Navigation — Public Internet Deployment

## Recommended production architecture

Parent Mobile (4G/5G / Internet)
→ HTTPS `navigation.your-school-domain.com`
→ Public DNS
→ School static public IP
→ Sophos XGS firewall
→ HTTPS reverse proxy (Nginx/IIS)
→ MSDGS Navigation application on `127.0.0.1:8080`

Do NOT expose Flask's development server directly to the internet.

## Application server
Run `INSTALL.bat`, then use `START_PRODUCTION.bat`.

Recommended environment variables:
- `MSDGS_SECRET` = long random application secret
- `MSDGS_HOST` = `127.0.0.1` when reverse proxy is on the same server
- `MSDGS_PORT` = `8080`
- `MSDGS_THREADS` = `12`

## Domain
Create a DNS A record such as:

`navigation.your-school-domain.com` → your school's static public IP

## Firewall / NAT
Publish only the HTTPS service required by the reverse proxy. Do not publish the SQLite database, Python folders, admin files, or port 8080 directly to the public internet.

## HTTPS
Use a valid TLS certificate. HTTPS is important for PWA/service-worker behavior and browser camera security for the Admin mapping page.

## Offline floors
Parents first open the public site over mobile data/Wi-Fi. They can select a branch and tap:
`DOWNLOAD THIS BRANCH FOR OFFLINE USE`

The browser caches the selected campus data/routes. If connectivity disappears inside the building, cached navigation can continue.

## Public vs Admin
Public navigation requires no login and no camera.
Admin remains authenticated and camera mapping is restricted to Admin/Mapper workflows.

## Before production
1. Change the default admin password.
2. Set a strong `MSDGS_SECRET`.
3. Back up `data/msdgs_navigation.db`.
4. Put the application behind HTTPS.
5. Restrict server management/RDP to trusted networks/VPN.
6. Test mobile data access from outside school Wi-Fi.
7. Test offline navigation after downloading a branch.
8. Keep draft maps unpublished until reviewed.

## Scaling note
SQLite is suitable for the current MVP and mapping development. Before a large public rollout with substantial concurrent administration/writes, migrate persistent data to PostgreSQL or another production database. Static/3D assets can also be moved to object/static storage or a CDN later.
