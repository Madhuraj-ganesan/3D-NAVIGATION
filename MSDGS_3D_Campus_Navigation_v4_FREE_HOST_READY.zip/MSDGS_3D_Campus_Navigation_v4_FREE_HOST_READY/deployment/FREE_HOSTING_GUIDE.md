# Free-host deployment package

## Recommended for this current Python/Flask build: Render Web Service

This application is not only a static website. It contains a Python/Flask backend for:
- Admin login
- Branch/building/floor/location management
- Route calculation
- Draft/publish map management
- Mapping sessions

Therefore a plain static Netlify drag-and-drop deployment is not sufficient for the full application.

## Render deployment

1. Create a GitHub repository.
2. Upload the CONTENTS of this package to the repository root.
3. Create a Render account.
4. Choose **New > Web Service**.
5. Connect the GitHub repository.
6. Render can use the included `render.yaml`, or configure:
   - Runtime: Python
   - Build: `pip install -r requirements.txt`
   - Start: `python render_server.py`
7. Select the Free instance for testing.
8. Deploy.
9. Render provides an HTTPS `*.onrender.com` URL.
10. Open that URL from the parent's mobile network.

## Important free-tier database limitation

The current app uses SQLite. Render's free web-service filesystem is ephemeral, so Admin-created branch/map changes can disappear after restart/redeploy/spin-down.

The included free-host configuration is therefore intended for internet-access testing/demo.

For a real school production rollout, connect the application to a persistent managed database (recommended: PostgreSQL) before entering all branch maps.

## Offline navigation

The PWA/service worker remains included. A parent can open the hosted HTTPS site, select a branch and download its navigation data before walking into low-connectivity floors.

## Netlify

`netlify_static_preview/` and `netlify.toml` are included only so you can deploy a static preview to Netlify.

The full current Flask Admin/API application should not be treated as a static Netlify site. Converting the entire backend to Netlify Functions/database would be a separate architecture migration.

## Production recommendation

Free hosting is appropriate for your testing stage. For actual parent-facing deployment, use persistent database storage and a service without free-tier sleep/data-loss limitations.
