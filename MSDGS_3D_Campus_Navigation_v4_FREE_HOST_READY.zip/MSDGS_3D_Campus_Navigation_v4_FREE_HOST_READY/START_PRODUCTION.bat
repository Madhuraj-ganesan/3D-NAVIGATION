@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Please run INSTALL.bat first.
 pause
 exit /b 1
)
call .venv\Scripts\activate
if "%MSDGS_SECRET%"=="" (
 echo WARNING: MSDGS_SECRET environment variable is not set.
 echo Set a long random secret before public deployment.
)
python production_server.py
pause
